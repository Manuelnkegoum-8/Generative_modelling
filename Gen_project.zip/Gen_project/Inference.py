from utils.init_models import *
from sklearn.preprocessing import StandardScaler
import pandas as pd
import argparse
import os
import numpy as np
import joblib


parser = argparse.ArgumentParser()
parser.add_argument("--samples", type=int, default=410)
parser.add_argument("--model", type=str, default='realnvp')
current_path = os.path.dirname(os.path.abspath(__file__))

# REALNVP PARAMETERS
DIM = 4
NUM_LAYERS = 4
HIDDEN_DIM = 64

# DIFFUSION PARAMETERS
DIM = 4
N_STEPS = 100
BETA_1 = 0.0001
BETA_T = 0.02

# GAN PARAMETERS
# Parameters
LATENT_DIM = 64  # latent dim
DATA_dim = 4    # data dimension


scaler = joblib.load('scaler.save') #scaler for GAN and Diffusion

def inference_realnvp(model, num_samples,device):
    with torch.no_grad():
        samples, x = model.sample(num_samples,device)
        samples  = samples.detach().cpu().numpy()
        x = x.detach().cpu().numpy()
    return samples, x

def inference_diffusion(model,num_samples,device):
    test_z = torch.randn(num_samples, DIM)
    with torch.no_grad():
        batch = torch.Tensor(test_z)
        sample, all_samples = model.denoise(batch.to(device), N_STEPS)
        sample = scaler.inverse_transform(sample.cpu().numpy())
    return test_z,sample

def inference_gan(model,num_samples,device):
    test_z = torch.randn(num_samples, LATENT_DIM)
    with torch.no_grad():
        batch = torch.Tensor(test_z)
        sample = model(batch.to(device))
        sample = scaler.inverse_transform(sample.cpu().numpy())
    return test_z,sample

    
if __name__== "__main__":

    args = parser.parse_args()
    num_samples = args.samples
    model_type = args.model

    #LOAD THE MODEL
    
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    
    if model_type=='realnvp':
        print("[INFO] : Loading {0} model".format(model_type))
        print("[INFO] : Generating samples")
        path = os.path.join(current_path,'Realnvp/RealNVP_model.pt')
        model = init_realnvp_model(path,device,DIM,NUM_LAYERS,HIDDEN_DIM)
        latent,generated = inference_realnvp(model,num_samples,device)
    elif model_type=='gan':
        print("[INFO] : Loading {0} model".format(model_type))
        print("[INFO] : Generating samples")
        path = os.path.join(current_path,'GAN/GAN_Generator.pt')
        model = init_gan_model(path,device,LATENT_DIM,DATA_dim)
        latent,generated = inference_gan(model,num_samples,device)
    elif model_type=='diffusion':
        print("[INFO] : Loading {0} model".format(model_type))
        print("[INFO] : Generating samples")
        path = os.path.join(current_path,'Diffusion/diffusion_model.pt')
        model = init_diffusion_model(path,device,N_STEPS,BETA_1,BETA_T)
        latent,generated = inference_diffusion(model,num_samples,device)
    else:
        raise ValueError ("{0} model not implemented".format(model_type)) 


    #SAVE
    print("[INFO] : Succesfully generated samples")
    latent_space = pd.DataFrame()
    observed = pd.DataFrame()
    cols = np.arange(latent.shape[1])
    latent_space[cols] = latent
    observed[[0,1,2,3]] = generated
    latent_space.to_csv(os.path.join(current_path,'latent.csv'),index=False)
    observed.to_csv(os.path.join(current_path,'generated_samples.csv'),index=False)

