from Realnvp.Normflow import Real_nvp
from Diffusion.diffusion_model import DiffusionModel, NoiseModel
from GAN.GAN_model import Generator
import torch

def init_realnvp_model(path, device,dim,num_layers,hidden_dim):
    # INIT THE MASKS
    init_mask = torch.zeros(dim)
    for i in range(dim//2,dim):
        init_mask[i] = 1.
    masks = [init_mask]

    for i in range(1, num_layers):
        masks.append(1-masks[i-1])
        
    # load
    model = Real_nvp(
    			dim=dim,
    			hidden_dim=hidden_dim,
    			num_coupling=num_layers,
    			masks=masks
    			)
    model.load_state_dict(torch.load(path, map_location=device))
    model = model.to(device)
    return model


def init_diffusion_model(path,device,n_steps,beta_1,beta_t):
    model = NoiseModel(n_steps)
    model.load_state_dict(torch.load(path, map_location=device))
    diffuser = DiffusionModel(model.eval(), n_steps, beta_1, beta_t, device)
    return diffuser

def init_gan_model(path,device,latent_dim, data_dim):
    # initialize
    generator = Generator(latent_dim, data_dim).to(device)
    generator.load_state_dict(torch.load(path,map_location=device))
    return generator